using System.Collections.Generic;
using System.Threading.Tasks;
namespace PortfolioTrackerApi.Services
{
    public interface IEmailVerificationService
    {
        void SendVerificationCode(string email);
        bool VerifyCode(string email, string code);
    }
}