using System;
using System.Collections.Concurrent;
using System.Net.Mail;
 
namespace PortfolioTrackerApi.Services
{
    public class EmailVerificationService : IEmailVerificationService
    {
        private readonly ConcurrentDictionary<string, VerificationEntry> _verificationCodes = new();
        private readonly TimeSpan _codeExpiration = TimeSpan.FromMinutes(5); // 5 minutes
 
        public void SendVerificationCode(string email)
        {
            if (!IsValidEmail(email))
                throw new ArgumentException("Invalid email address.");
 
            var code = new Random().Next(100000, 999999).ToString();
 
            var entry = new VerificationEntry
            {
                Code = code,
                CreatedAt = DateTime.UtcNow
            };
 
            _verificationCodes[email] = entry;
 
            // --- Call real email sending ---
            SendEmail(email, code);
 
            Console.WriteLine($"[Email to {email}]: Your verification code is {code}");
        }
 
        public bool VerifyCode(string email, string code)
        {
            if (_verificationCodes.TryGetValue(email, out var entry))
            {
                if (DateTime.UtcNow - entry.CreatedAt > _codeExpiration)
                {
                    _verificationCodes.TryRemove(email, out _);
                    return false; // expired
                }
 
                if (entry.Code == code)
                {
                    _verificationCodes.TryRemove(email, out _);
                    return true; // valid
                }
            }
            return false;
        }
 
        private bool IsValidEmail(string email)
        {
            try
            {
                var addr = new MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }
 
        // --- New: send actual email ---
        private void SendEmail(string toEmail, string code)
        {
            var fromAddress = new MailAddress("ruchibalapada2816@gmail.com", "Portfolio Tracker"); // Your Gmail
            var toAddress = new MailAddress(toEmail);
            const string fromPassword = "kksf cfgm vlgk ekar"; // Your app password (not your Gmail password)
            const string subject = "Your Verification Code";
            string body = $"Your verification code is: {code}";
 
            var smtp = new System.Net.Mail.SmtpClient
            {
                Host = "smtp.gmail.com",
                Port = 587,
                EnableSsl = true,
                DeliveryMethod = System.Net.Mail.SmtpDeliveryMethod.Network,
                UseDefaultCredentials = false,
                Credentials = new System.Net.NetworkCredential(fromAddress.Address, fromPassword)
            };
            using var message = new MailMessage(fromAddress, toAddress)
            {
                Subject = subject,
                Body = body
            };
            smtp.Send(message);
        }
 
        private class VerificationEntry
        {
            public string Code { get; set; }
            public DateTime CreatedAt { get; set; }
        }
    }
}